function Dashboard() {
  return (
    <>
      <h1>DASHBOARD</h1>

      <h3>Skills</h3>
      <ol>
        <li>C++</li>
        <li>Python</li>
        <li>Logo Designing</li>
        <li>Video Editing</li>
      </ol>

      <h3>Achievements</h3>
      <ol>
        <li>tekathon 2.0 qualifier</li>
        <li>feet on fire winner</li>
      </ol>
    </>
  );
}
export default Dashboard;