
function Profile() {
  return (
    <>


      <h2>Projects</h2>
      <ol>
        <li>Disease Prediction Model</li>
        <li>Weather Prediction Model</li>
        <li>Antivirus Software</li>
      </ol>
    </>
  );
}

export default Profile;